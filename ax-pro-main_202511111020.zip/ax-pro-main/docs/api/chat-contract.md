# Chat API Contract (Draft)

Request: messages[], stream?: boolean
Response: { reply } or SSE data: <delta>
