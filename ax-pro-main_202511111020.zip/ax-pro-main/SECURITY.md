# SECURITY

Never commit secrets. Use server proxy. See checklist later.
