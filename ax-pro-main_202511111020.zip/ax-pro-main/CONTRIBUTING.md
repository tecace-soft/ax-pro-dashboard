# CONTRIBUTING

Use conventional commits. Small PRs. Branch `feat/*`, `fix/*`.
